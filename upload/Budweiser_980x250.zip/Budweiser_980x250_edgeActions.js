
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'nobong'
(function(symbolName){Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",2450,function(sym,e){sym.play(0);});
//Edge binding end
})("nobong");
//Edge symbol end:'nobong'
})(jQuery,AdobeEdge,"EDGE-950968304");